package br.fepi.socialbooks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiSocialBooksApplicationTests {

	@Test
	void contextLoads() {
	}

}
